let mens = document.getElementById("mens");
let womens = document.getElementById("womens");
let kid = document.getElementById("kid");
let offer = document.getElementById("offer");
let contacts = document.getElementById("contact");


mens.addEventListener("click",function(){
    mens.style.color="grey";
    womens.style.color="white";
    kid.style.color="white";
    offer.style.color="white";
    contacts.style.color="white";
    
})
womens.addEventListener("click",function(){
    mens.style.color="white";
    womens.style.color="grey";
    kid.style.color="white";
    offer.style.color="white";
    contacts.style.color="white";
    
})
kid.addEventListener("click",function(){
    mens.style.color="white";
    womens.style.color="white";
    kid.style.color="grey";
    offer.style.color="white";
    contacts.style.color="white";
    
})
offer.addEventListener("click",function(){
    mens.style.color="white";
    womens.style.color="white";
    kid.style.color="white";
    offer.style.color="grey";
    contacts.style.color="white";
    
})
contact.addEventListener("click",function(){
    mens.style.color="grey";
    womens.style.color="white";
    kid.style.color="white";
    offer.style.color="white";
    contacts.style.color="grey";
    
})
let login=document.getElementById("login")
login.addEventListener("click",function(){
    let loginpage = document.getElementById("loginpage").style.display="block";
    
   
})
let search=document.querySelector("searchbar");
document.querySelector('#search').onclick=()=>{
    search.classList.toggle('active');
}